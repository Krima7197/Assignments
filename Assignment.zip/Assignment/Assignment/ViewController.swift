//
//  ViewController.swift
//  Assignment
//
//  Created by TOPS on 8/27/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    /*
     Create mutable array and perform following functionality.
     1. → append object in array
     2. → insert object at 2nd position
     3. → update 2nd position object
     4. → remove object at position 2nd
     */
    struct emp
    {   var no:Int=1
        var name:String="krima\n"
        var age:Int=20
        var add:String="katargam"
        func disp()  {
            print(no,name,age,add)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        var obj:[emp] = []
        let obj1=emp()
        obj.append(obj1)
        obj.append(obj1)
        
        for i in obj
        {   i.disp()
        }
        /*var arr=[1,2,3,4,5,6,7,8,9]
        for i in 0...arr.count
        {
        
        //print(arr)
        arr.append(10)
        //print(arr)
        arr.insert(11, at: 2)
            
        //print(arr)
        arr[2] = 15
        //print(arr)
        arr.remove(at: 2)
        //print(arr)
        print(arr[i])
        }*/
    }
            override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.

    }
}
